<?php
// Text
$_['text_payment_desc']           = 'Payment for order #%s';

$_['text_comment']                = 'Order #%s successfully paid via PayCore.io';
$_['text_comment_payment_status']           = 'PayCore.io: payment failed.';

$_['text_error_order_not_found']  = 'Order #%s node found';
?>