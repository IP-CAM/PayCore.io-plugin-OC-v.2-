<?php
// Text
$_['text_payment_desc']           = 'Оплата заказа №%s';

$_['text_comment']                = 'Заказ №%s успешно оплачен через PayCore.io';
$_['text_comment_fail']           = 'PayCore.io: оплата не удалась.';

$_['text_error_order_not_found']  = 'Заказ № "%s" не найден';
?>